/*
Elena Norris, COP4634
Project 1 - Part 1
Zolfghari
*/
#ifndef PARSE_HPP
#define PARSE_HPP
#include "param.hpp"
// this will parse the input string and put it in the Param object
void parseInput(const char *input, Param &param);
#endif 